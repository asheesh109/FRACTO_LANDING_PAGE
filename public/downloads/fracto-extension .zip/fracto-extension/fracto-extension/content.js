// content.js - Fracto Content Script

// ── Guard: prevent SyntaxError if injected twice ────────────────────────────
if (window.__fractoLoaded) {
  // Script already running — just toggle the overlay
  if (window.__fractoToggle) window.__fractoToggle();
} else {
  window.__fractoLoaded = true;

let fractoActive = false;
let selectionBox = null;
let overlay = null;
let startX, startY;
let isDragging = false;
let resultCard = null;

// Listen for activation from background
// IMPORTANT: sendResponse({ok:true}) so background knows the script is alive
// (without a response, background sees undefined and tries to re-inject)
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === "ACTIVATE_FRACTO") {
    toggleFracto();
    sendResponse({ ok: true });
  }
});

function toggleFracto() {
  fractoActive ? deactivateFracto() : activateFracto();
}

function activateFracto() {
  fractoActive = true;
  document.body.classList.add("fracto-mode");

  overlay = document.createElement("div");
  overlay.id = "fracto-overlay";
  overlay.innerHTML = `
    <div id="fracto-hint">
      <div class="fracto-hint-inner">
        <span class="fracto-icon">⬡</span>
        <span>Drag to select area to fact-check</span>
        <kbd>ESC</kbd>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);

  selectionBox = document.createElement("div");
  selectionBox.id = "fracto-selection";
  document.body.appendChild(selectionBox);

  overlay.addEventListener("mousedown", onMouseDown);
  document.addEventListener("mousemove", onMouseMove);
  document.addEventListener("mouseup", onMouseUp);
  document.addEventListener("keydown", onKeyDown);
}

function deactivateFracto() {
  fractoActive = false;
  isDragging = false;
  document.body.classList.remove("fracto-mode");

  if (overlay)      { overlay.remove();      overlay      = null; }
  if (selectionBox) { selectionBox.remove(); selectionBox = null; }
  removeResultCard();

  document.removeEventListener("mousemove", onMouseMove);
  document.removeEventListener("mouseup",   onMouseUp);
  document.removeEventListener("keydown",   onKeyDown);
}

function onKeyDown(e) {
  if (e.key === "Escape") deactivateFracto();
}

function onMouseDown(e) {
  if (e.button !== 0) return;
  removeResultCard();
  isDragging = true;
  startX = e.clientX;
  startY = e.clientY;

  selectionBox.style.display = "block";
  selectionBox.style.left   = startX + "px";
  selectionBox.style.top    = startY + "px";
  selectionBox.style.width  = "0px";
  selectionBox.style.height = "0px";

  const hint = document.getElementById("fracto-hint");
  if (hint) hint.style.opacity = "0";
}

function onMouseMove(e) {
  if (!isDragging) return;
  const x = Math.min(e.clientX, startX);
  const y = Math.min(e.clientY, startY);

  selectionBox.style.left   = x + "px";
  selectionBox.style.top    = y + "px";
  selectionBox.style.width  = Math.abs(e.clientX - startX) + "px";
  selectionBox.style.height = Math.abs(e.clientY - startY) + "px";
}

function onMouseUp(e) {
  if (!isDragging) return;
  isDragging = false;

  const rect = selectionBox.getBoundingClientRect();
  if (rect.width < 20 || rect.height < 20) {
    selectionBox.style.display = "none";
    return;
  }
  captureAndAnalyze(rect);
}

// ── Main pipeline ─────────────────────────────────────────────────────────────

async function captureAndAnalyze(rect) {
  showResultCard(rect, "loading", { step: 1 });

  try {
    // Step 1 — screenshot the selected region
    const imageData = await captureRegion(rect);

    // Step 2 — fetch both stored API keys
    const { openRouterKey, mediastackKey } = await chrome.runtime.sendMessage({ action: "GET_API_KEYS" });

    if (!openRouterKey) { showResultCard(rect, "no-key", { which: "openrouter" }); return; }
    if (!mediastackKey) { showResultCard(rect, "no-key", { which: "mediastack" }); return; }

    // Update loading to step 2 label while AI parses
    showResultCard(rect, "loading", { step: 2 });

    // Step 3 — background does OpenRouter → Mediastack
    const response = await chrome.runtime.sendMessage({
      action:        "ANALYZE_CONTENT",
      imageData,
      openRouterKey,
      mediastackKey
    });

    if (response.success) {
      showResultCard(rect, "result", response.result);
    } else {
      showResultCard(rect, "error", { message: response.error });
    }

  } catch (err) {
    showResultCard(rect, "error", { message: err.message });
  }
}

// ── Screenshot capture ────────────────────────────────────────────────────────

async function captureRegion(rect) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action: "CAPTURE_TAB_SCREENSHOT" }, (response) => {
      if (!response || !response.dataUrl) {
        reject(new Error("Screenshot failed. Please try again."));
        return;
      }
      const img = new Image();
      img.onload = () => {
        const dpr = window.devicePixelRatio || 1;

        // Crop the selected region
        const cropW = rect.width;
        const cropH = rect.height;
        const cropCanvas = document.createElement("canvas");
        cropCanvas.width  = cropW;
        cropCanvas.height = cropH;
        cropCanvas.getContext("2d").drawImage(
          img,
          rect.left * dpr, rect.top * dpr,
          cropW * dpr,     cropH * dpr,
          0, 0,
          cropW,           cropH
        );

        // Upscale to at least 600×300 so the vision model can read text reliably
        const MIN_W = 600;
        const MIN_H = 300;
        const scaleW = cropW < MIN_W ? MIN_W / cropW : 1;
        const scaleH = cropH < MIN_H ? MIN_H / cropH : 1;
        const scale  = Math.max(scaleW, scaleH, 1);

        if (scale > 1) {
          const upCanvas = document.createElement("canvas");
          upCanvas.width  = Math.round(cropW * scale);
          upCanvas.height = Math.round(cropH * scale);
          const upCtx = upCanvas.getContext("2d");
          upCtx.imageSmoothingEnabled = true;
          upCtx.imageSmoothingQuality = "high";
          upCtx.drawImage(cropCanvas, 0, 0, upCanvas.width, upCanvas.height);
          resolve(upCanvas.toDataURL("image/png"));
        } else {
          resolve(cropCanvas.toDataURL("image/png"));
        }
      };
      img.onerror = () => reject(new Error("Failed to load screenshot image."));
      img.src = response.dataUrl;
    });
  });
}


// ── Result card ───────────────────────────────────────────────────────────────

function showResultCard(rect, state, data = {}) {
  removeResultCard();

  resultCard = document.createElement("div");
  resultCard.id = "fracto-result-card";

  const cardWidth = 310;
  let left = rect.right + 14;
  let top  = rect.top;

  if (left + cardWidth > window.innerWidth - 20) left = rect.left - cardWidth - 14;
  if (left < 10) left = 10;
  if (top + 340 > window.innerHeight) top = Math.max(10, window.innerHeight - 350);

  resultCard.style.left = left + window.scrollX + "px";
  resultCard.style.top  = top  + window.scrollY + "px";

  // ── Loading ────────────────────────────────────────────────────────────────
  if (state === "loading") {
    const stepLabel = data.step === 2
      ? "Step 2 / 2 — Verifying with news sources…"
      : "Step 1 / 2 — AI is reading the content…";

    resultCard.innerHTML = `
      <div class="fracto-card fracto-loading">
        <div class="fracto-card-header">
          <span class="fracto-logo">⬡ FRACTO</span>
        </div>
        <div class="fracto-spinner-wrap">
          <div class="fracto-spinner"></div>
          <span>${stepLabel}</span>
        </div>
        <div class="fracto-steps-row">
          <div class="fracto-step ${data.step >= 1 ? "fracto-step-active" : ""}">
            <span>1</span> Parse
          </div>
          <div class="fracto-step-line"></div>
          <div class="fracto-step ${data.step >= 2 ? "fracto-step-active" : ""}">
            <span>2</span> Verify
          </div>
        </div>
      </div>
    `;

  // ── Missing key ────────────────────────────────────────────────────────────
  } else if (state === "no-key") {
    const isOR = data.which === "openrouter";
    resultCard.innerHTML = `
      <div class="fracto-card fracto-warn">
        <div class="fracto-card-header">
          <span class="fracto-logo">⬡ FRACTO</span>
          <button class="fracto-close" id="fracto-close-btn">✕</button>
        </div>
        <div class="fracto-body">
          <div class="fracto-verdict-icon">🔑</div>
          <p class="fracto-reason">
            <strong>${isOR ? "OpenRouter" : "Mediastack"} API key</strong> is not set.<br>
            Click the Fracto icon in your toolbar and enter both keys.
          </p>
          <div class="fracto-keys-needed">
            <div class="fracto-key-row ${isOR ? "fracto-key-missing" : "fracto-key-ok"}">
              ${isOR ? "⚠️" : "✅"} OpenRouter key (AI text parser)
            </div>
            <div class="fracto-key-row ${!isOR ? "fracto-key-missing" : "fracto-key-ok"}">
              ${!isOR ? "⚠️" : "✅"} Mediastack key (news verifier)
            </div>
          </div>
        </div>
      </div>
    `;

  // ── Error ──────────────────────────────────────────────────────────────────
  } else if (state === "error") {
    resultCard.innerHTML = `
      <div class="fracto-card fracto-error">
        <div class="fracto-card-header">
          <span class="fracto-logo">⬡ FRACTO</span>
          <button class="fracto-close" id="fracto-close-btn">✕</button>
        </div>
        <div class="fracto-body">
          <div class="fracto-verdict-icon">⚠️</div>
          <p class="fracto-reason">${escHtml(data.message || "Analysis failed. Please try again.")}</p>
        </div>
      </div>
    `;

  // ── Result ─────────────────────────────────────────────────────────────────
  } else if (state === "result") {
    const { found, articles, query, extractedText, totalResults } = data;

    // What the AI extracted — shown in both states
    const aiTextHtml = extractedText
      ? `<div class="fracto-ai-extract">
           <span class="fracto-ai-label">🤖 AI extracted:</span>
           <span class="fracto-ai-text">"${escHtml(extractedText)}"</span>
         </div>`
      : "";

    if (found) {
      // ── VERIFIED ─────────────────────────────────────────────────────────
      const articlesHtml = articles.map((a) => {
        const source  = typeof a.source === "string" && a.source
          ? escHtml(a.source)
          : (a.source?.name ? escHtml(a.source.name) : "Unknown Source");
        const title   = escHtml(a.title || "Untitled");
        const rawDesc = a.description || "";
        const desc    = rawDesc
          ? escHtml(rawDesc.slice(0, 90)) + (rawDesc.length > 90 ? "…" : "")
          : "";
        const dateStr = a.published_at || a.publishedAt || "";
        const pub     = dateStr
          ? new Date(dateStr).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
          : "";

        return `
          <a class="fracto-article" href="${a.url}" target="_blank" rel="noopener">
            <div class="fracto-article-meta">
              <span class="fracto-source-badge">${source}</span>
              ${pub ? `<span class="fracto-pub-date">${pub}</span>` : ""}
            </div>
            <div class="fracto-article-title">${title}</div>
            ${desc ? `<div class="fracto-article-desc">${desc}</div>` : ""}
          </a>
        `;
      }).join("");

      resultCard.innerHTML = `
        <div class="fracto-card fracto-verified">
          <div class="fracto-card-header">
            <span class="fracto-logo">⬡ FRACTO</span>
            <button class="fracto-close" id="fracto-close-btn">✕</button>
          </div>
          <div class="fracto-verdict-banner fracto-verified-banner">
            <span class="fracto-verdict-emoji">✅</span>
            <div>
              <div class="fracto-verdict-title">NEWS VERIFIED</div>
              <div class="fracto-verdict-sub">${totalResults} matching source${totalResults !== 1 ? "s" : ""} found</div>
            </div>
          </div>
          ${aiTextHtml}
          <div class="fracto-query-chip">🔍 "${escHtml(query)}"</div>
          <div class="fracto-articles-list">${articlesHtml}</div>
        </div>
      `;

    } else {
      // ── UNVERIFIED ────────────────────────────────────────────────────────
      resultCard.innerHTML = `
        <div class="fracto-card fracto-fake">
          <div class="fracto-card-header">
            <span class="fracto-logo">⬡ FRACTO</span>
            <button class="fracto-close" id="fracto-close-btn">✕</button>
          </div>
          <div class="fracto-verdict-banner fracto-fake-banner">
            <span class="fracto-verdict-emoji">🚫</span>
            <div>
              <div class="fracto-verdict-title">UNVERIFIED</div>
              <div class="fracto-verdict-sub">No credible sources found</div>
            </div>
          </div>
          ${aiTextHtml}
          <div class="fracto-query-chip">🔍 "${escHtml(query)}"</div>
          <div class="fracto-body">
            <p class="fracto-reason">
              No matching news articles were found for the extracted claim.
              This may be <strong>misinformation, satire, or simply unreported</strong>.
              Always verify with trusted outlets before sharing.
            </p>
            <div class="fracto-warning">
              ⚠️ Absence from news sources does not guarantee falsehood — treat with caution.
            </div>
          </div>
        </div>
      `;
    }
  }

  document.body.appendChild(resultCard);

  const closeBtn = document.getElementById("fracto-close-btn");
  if (closeBtn) {
    closeBtn.addEventListener("click", () => {
      removeResultCard();
      if (selectionBox) selectionBox.style.display = "none";
      const hint = document.getElementById("fracto-hint");
      if (hint) hint.style.opacity = "1";
    });
  }

  // Prevent article clicks from triggering the overlay
  resultCard.querySelectorAll("a.fracto-article").forEach((a) => {
    a.addEventListener("mousedown", (e) => e.stopPropagation());
  });
}

function removeResultCard() {
  if (resultCard) { resultCard.remove(); resultCard = null; }
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Expose toggle so the guard at the top can call it if re-injected
window.__fractoToggle = toggleFracto;

} // end of window.__fractoLoaded guard
