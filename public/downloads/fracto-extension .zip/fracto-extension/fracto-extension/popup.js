// popup.js

// ── Activate button ─────────────────────────────────────────────────────────
const activateBtn = document.getElementById("activate-btn");

activateBtn.addEventListener("click", () => {
  activateBtn.textContent = "⬡  Activating…";
  activateBtn.style.opacity = "0.7";

  chrome.runtime.sendMessage({ action: "ACTIVATE_ON_TAB" }, () => {
    window.close(); // close popup so user can draw selection on the page
  });
});



const orInput     = document.getElementById("or-key-input");
const orSaveBtn   = document.getElementById("or-save-btn");
const orStatusMsg = document.getElementById("or-status-msg");
const orToggleVis = document.getElementById("or-toggle-vis");
const orDot       = document.getElementById("or-status-dot");

const msInput     = document.getElementById("ms-key-input");
const msSaveBtn   = document.getElementById("ms-save-btn");
const msStatusMsg = document.getElementById("ms-status-msg");
const msToggleVis = document.getElementById("ms-toggle-vis");
const msDot       = document.getElementById("ms-status-dot");

// ── Load existing keys on open ───────────────────────────────────────────────

chrome.runtime.sendMessage({ action: "GET_API_KEYS" }, ({ openRouterKey, mediastackKey }) => {
  if (openRouterKey) {
    orInput.value = openRouterKey;
    orDot.classList.add("active");
  }
  if (mediastackKey) {
    msInput.value = mediastackKey;
    msDot.classList.add("active");
  }
});

// ── Toggle visibility ────────────────────────────────────────────────────────

orToggleVis.addEventListener("click", () => {
  orInput.type = orInput.type === "password" ? "text" : "password";
  orToggleVis.textContent = orInput.type === "password" ? "👁" : "🙈";
});

msToggleVis.addEventListener("click", () => {
  msInput.type = msInput.type === "password" ? "text" : "password";
  msToggleVis.textContent = msInput.type === "password" ? "👁" : "🙈";
});

// ── Save OpenRouter key ──────────────────────────────────────────────────────

orSaveBtn.addEventListener("click", () => {
  const key = orInput.value.trim();
  if (!key) {
    showStatus(orStatusMsg, "Please enter your OpenRouter key.", "error");
    return;
  }
  if (!key.startsWith("sk-or-")) {
    showStatus(orStatusMsg, "Key should start with sk-or-…", "error");
    return;
  }
  chrome.runtime.sendMessage(
    { action: "SAVE_API_KEYS", openRouterKey: key },
    () => {
      orDot.classList.add("active");
      showStatus(orStatusMsg, "OpenRouter key saved ✓", "success");
    }
  );
});

// ── Save Mediastack key ──────────────────────────────────────────────────────

msSaveBtn.addEventListener("click", () => {
  const key = msInput.value.trim();
  if (!key) {
    showStatus(msStatusMsg, "Please enter your Mediastack key.", "error");
    return;
  }
  if (key.length < 10) {
    showStatus(msStatusMsg, "That doesn't look like a valid key.", "error");
    return;
  }
  chrome.runtime.sendMessage(
    { action: "SAVE_API_KEYS", mediastackKey: key },
    () => {
      msDot.classList.add("active");
      showStatus(msStatusMsg, "Mediastack key saved ✓", "success");
    }
  );
});

// ── Helper ───────────────────────────────────────────────────────────────────

function showStatus(el, msg, type) {
  el.textContent = msg;
  el.className   = "key-status-msg " + type;
  setTimeout(() => {
    el.textContent = "";
    el.className   = "key-status-msg";
  }, 3000);
}
