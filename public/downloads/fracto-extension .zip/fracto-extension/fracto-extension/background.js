// background.js - Fracto Service Worker

// ── Command: keyboard shortcut ────────────────────────────────────────────────
chrome.commands.onCommand.addListener((command) => {
  if (command === "activate-fracto") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) activateOnTab(tabs[0].id);
    });
  }
});

// ── Inject content script on-demand then activate ────────────────────────────
//
// chrome.tabs.sendMessage does NOT reject when there is no listener — it calls
// the callback with undefined and sets chrome.runtime.lastError.  Wrapping in
// a plain callback (not await) lets us check lastError explicitly.
//
function activateOnTab(tabId) {
  chrome.tabs.sendMessage(tabId, { action: "ACTIVATE_FRACTO" }, (response) => {
    // Suppress the "no listener" error — we handle it by injecting the script
    void chrome.runtime.lastError;

    if (response === undefined) {
      // Content script not present — inject it, then activate
      chrome.scripting.executeScript(
        { target: { tabId }, files: ["content.js"] },
        () => {
          if (chrome.runtime.lastError) {
            console.error("Fracto inject error:", chrome.runtime.lastError.message);
            return;
          }
          chrome.scripting.insertCSS(
            { target: { tabId }, files: ["fracto.css"] },
            () => {
              void chrome.runtime.lastError;
              // Give the script a moment to initialise
              setTimeout(() => {
                chrome.tabs.sendMessage(tabId, { action: "ACTIVATE_FRACTO" }, () => {
                  void chrome.runtime.lastError;
                });
              }, 200);
            }
          );
        }
      );
    }
  });
}

// ── Message router ────────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // Activate from popup button
  if (message.action === "ACTIVATE_ON_TAB") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0]) activateOnTab(tabs[0].id);
      sendResponse({ success: true });
    });
    return true;
  }

  // Capture the visible tab as a PNG data URL
  if (message.action === "CAPTURE_TAB_SCREENSHOT") {
    chrome.tabs.captureVisibleTab(sender.tab.windowId, { format: "png" }, (dataUrl) => {
      if (chrome.runtime.lastError) {
        sendResponse({ error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ dataUrl });
      }
    });
    return true;
  }

  // Two-step analysis: OpenRouter → Mediastack
  if (message.action === "ANALYZE_CONTENT") {
    analyzeContent(message.imageData, message.openRouterKey, message.mediastackKey)
      .then((result) => sendResponse({ success: true, result }))
      .catch((err)  => sendResponse({ success: false, error: err.message }));
    return true;
  }

  // Load both saved API keys
  if (message.action === "GET_API_KEYS") {
    chrome.storage.sync.get(["fractoOpenRouterKey", "fractoMediastackKey"], (data) => {
      sendResponse({
        openRouterKey: data.fractoOpenRouterKey || null,
        mediastackKey: data.fractoMediastackKey || null
      });
    });
    return true;
  }

  // Save one or both API keys
  if (message.action === "SAVE_API_KEYS") {
    const toSave = {};
    if (message.openRouterKey != null) toSave.fractoOpenRouterKey = message.openRouterKey;
    if (message.mediastackKey  != null) toSave.fractoMediastackKey  = message.mediastackKey;
    chrome.storage.sync.set(toSave, () => sendResponse({ success: true }));
    return true;
  }
});

// ── Step 1 — OpenRouter: extract the main claim from the screenshot ───────────

async function extractTextWithOpenRouter(imageData, apiKey) {
  const base64 = imageData.replace(/^data:image\/png;base64,/, "");

  const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type":  "application/json",
      "Authorization": "Bearer " + apiKey,
      "HTTP-Referer":  "https://fracto-extension",
      "X-Title":       "Fracto Fake News Detector"
    },
    body: JSON.stringify({
      model:      "google/gemini-2.0-flash-lite-001",
      max_tokens: 200,
      messages: [{
        role: "user",
        content: [
          {
            type:      "image_url",
            image_url: { url: "data:image/png;base64," + base64 }
          },
          {
            type: "text",
            text: "Read the news text in this image.\n" +
                  "Provide 3-5 search keywords to find this story on a news website.\n" +
                  "Focus on: person or organisation name, country or city, core event type.\n" +
                  "Use neutral news language (e.g. 'strike' not 'obliterated', 'attack' not 'destroyed').\n" +
                  "Reply with ONLY the keywords, space-separated. No sentences, no punctuation.\n" +
                  "Example output: Trump Iran military strike"
          }
        ]
      }]
    })
  });

  // Log raw response body for debugging
  const data = await response.json();
  console.log("[Fracto] OpenRouter raw response:", JSON.stringify(data));

  if (!response.ok) {
    const msg = (data.error && data.error.message) || ("OpenRouter error " + response.status);
    if (response.status === 401) throw new Error("Invalid OpenRouter API key. Please check your key in the popup.");
    throw new Error(msg);
  }

  // Handle both string content and array-of-parts content formats
  const rawContent = data.choices &&
                     data.choices[0] &&
                     data.choices[0].message &&
                     data.choices[0].message.content;

  let text = "";
  if (typeof rawContent === "string") {
    text = rawContent.trim();
  } else if (Array.isArray(rawContent)) {
    // Some models return [{type:"text", text:"..."}]
    text = rawContent
      .filter((c) => c.type === "text" && c.text)
      .map((c) => c.text)
      .join(" ")
      .trim();
  }

  console.log("[Fracto] Extracted text:", text);

  if (!text) {
    // Surface the finish reason to help diagnose
    const finishReason = data.choices && data.choices[0] && data.choices[0].finish_reason;
    throw new Error(
      "AI returned no text (finish_reason: " + (finishReason || "unknown") + "). " +
      "Try selecting a larger area with clearly visible text."
    );
  }

  return text;
}

// ── Step 2 — Mediastack: verify with cache + rate limiter ────────────────────
//
//  • Results are cached for 5 minutes — rescanning same news = 0 API calls
//  • A 1.1-second gap is enforced between real API calls (free plan: 1 req/sec)
//  • Max 2 attempts per scan (down from 3) to conserve monthly quota

const _msCache  = new Map();                  // query → {result, ts}
const CACHE_TTL = 5 * 60 * 1000;             // 5 minutes
let   _lastCall = 0;                          // timestamp of last real API call
const MIN_GAP   = 1100;                       // ms — stay safely under 1 req/sec

async function verifyWithMediastack(extractedText, apiKey) {
  const queries = buildSearchQueries(extractedText).slice(0, 2); // max 2 attempts
  console.log("[Fracto] Query attempts:", queries);

  let lastResult = null;

  for (const query of queries) {
    const result = await callMediastack(query, apiKey);
    lastResult   = result;
    if (result.found) {
      console.log("[Fracto] Found results with query:", query);
      return result;
    }
    console.log("[Fracto] No results for:", query, "— trying fallback…");
  }

  return lastResult || {
    found: false, articles: [], extractedText,
    query: queries[0] || extractedText, totalResults: 0
  };
}

// Cached + rate-limited Mediastack call
async function callMediastack(query, apiKey) {
  // ── Cache hit ────────────────────────────────────────────────────
  const cached = _msCache.get(query);
  if (cached && (Date.now() - cached.ts) < CACHE_TTL) {
    console.log("[Fracto] Cache hit:", query);
    return cached.result;
  }

  // ── Rate limit guard: wait until 1.1s has passed since last call ─
  const wait = MIN_GAP - (Date.now() - _lastCall);
  if (wait > 0) {
    console.log("[Fracto] Rate limit pause:", wait, "ms");
    await new Promise((r) => setTimeout(r, wait));
  }
  _lastCall = Date.now();

  // ── Real API call ────────────────────────────────────────────────
  const params = new URLSearchParams({
    access_key: apiKey,
    keywords:   query,
    languages:  "en",
    sort:       "popularity",
    limit:      "5"
  });

  const response = await fetch("http://api.mediastack.com/v1/news?" + params.toString());
  const data     = await response.json();

  if (data.error) {
    const code = data.error.code || response.status;
    const msg  = data.error.message || ("Mediastack error " + code);
    if (code === 101 || code === 102) throw new Error("Invalid Mediastack API key. Please check your key in the popup.");
    if (code === 429)                 throw new Error("Rate limit hit. Please wait 60 seconds before scanning again.");
    throw new Error(msg);
  }
  if (!response.ok) throw new Error("Mediastack API error " + response.status);

  const raw      = Array.isArray(data.data) ? data.data : [];
  const articles = raw.filter((a) => a.title && a.url);

  const result = {
    found:         articles.length > 0,
    articles:      articles.slice(0, 3),
    query,
    extractedText: query,
    totalResults:  data.pagination ? data.pagination.total : articles.length
  };

  // ── Store in cache ───────────────────────────────────────────────
  _msCache.set(query, { result, ts: Date.now() });
  if (_msCache.size > 100) {
    // Evict the oldest entry
    _msCache.delete(_msCache.keys().next().value);
  }

  return result;
}


// Build up to 3 progressively simpler queries from AI keywords
function buildSearchQueries(text) {
  const allWords = text.replace(/[^a-zA-Z0-9\s]/g, " ").trim().split(/\s+/).filter(Boolean);

  // Proper nouns = originally capitalised (people, places, orgs — most reliable)
  const properNouns = allWords
    .filter((w) => /^[A-Z]/.test(w) && w.length > 1)
    .map((w) => w.toLowerCase());

  // Common non-trivial words
  const skipWords = new Set(["says","said","just","every","will","that","with",
    "from","into","over","after","have","this","they","were","been","their"]);
  const commonWords = allWords
    .filter((w) => !/^[A-Z]/.test(w) && w.length > 3 && !skipWords.has(w.toLowerCase()))
    .map((w) => w.toLowerCase());

  const queries = [];

  // Attempt 1: proper nouns + top common action words
  const q1 = [...new Set([...properNouns.slice(0, 3), ...commonWords.slice(0, 2)])]
               .join(" ").slice(0, 120).trim();
  if (q1) queries.push(q1);

  // Attempt 2: proper nouns only  ("Trump Iran" matches any phrasing of the story)
  const q2 = [...new Set(properNouns)].slice(0, 3).join(" ").trim();
  if (q2 && q2 !== q1) queries.push(q2);

  // Attempt 3: first 2 raw words of AI output
  const q3 = allWords.slice(0, 2).join(" ").toLowerCase().trim();
  if (q3 && q3 !== q1 && q3 !== q2) queries.push(q3);

  return queries.filter((q) => q.length > 2);
}

// ── Combined pipeline ─────────────────────────────────────────────────────────

async function analyzeContent(imageData, openRouterKey, mediastackKey) {
  const extractedText = await extractTextWithOpenRouter(imageData, openRouterKey);
  return await verifyWithMediastack(extractedText, mediastackKey);
}

// (Legacy extractKeywords kept for safety but no longer called)
function extractKeywords(rawText) {
  const words = rawText.replace(/[^a-zA-Z0-9\s]/g, " ").toLowerCase().split(/\s+/)
    .filter((w) => w.length > 3);
  const unique = [...new Set(words)].slice(0, 5);
  let query = "";
  for (const w of unique) {
    if ((query + " " + w).trim().length > 120) break;
    query = (query + " " + w).trim();
  }

  return query;
}
