# ⬡ FRACTO — Fake News & Scam Detector

**Instantly detect fake news, scams, and misinformation on any webpage.**

Select any part of your screen → Fracto analyzes it with AI → Get a verdict in seconds.

---

## How to Install

### Step 1 — Load the Extension in Chrome

1. Open Chrome and go to: `chrome://extensions`
2. Toggle **"Developer mode"** ON (top-right corner)
3. Click **"Load unpacked"**
4. Select the `fracto-extension` folder
5. Fracto is now installed! You'll see the ⬡ icon in your toolbar.

### Step 2 — Add Your API Key

1. Click the **⬡ Fracto icon** in your Chrome toolbar
2. Enter your **OpenRouter API key (get one FREE at openrouter.ai/keys)))
3. Click **Save Key**

> Your key is stored locally on your device only — never sent anywhere except Anthropic's API.

---

## How to Use

1. Press **`Ctrl + Shift + F`** on any webpage (Mac: `Cmd + Shift + F`)
2. The screen dims — you're in **Fracto mode**
3. **Click and drag** to select the area you want to analyze (like a news post, WhatsApp screenshot, or suspicious message)
4. Release — Fracto analyzes the content and shows a verdict card:
   - 🚫 **FAKE** — Misinformation or false claims
   - ⚠️ **SCAM** — Phishing, fraud, suspicious links
   - ✅ **REAL** — Looks legitimate
   - ❓ **UNCLEAR** — Not enough information
5. Press **ESC** to exit Fracto mode anytime

---

## Files

```
fracto-extension/
├── manifest.json       — Extension config & permissions
├── background.js       — Service worker: screenshot capture + AI analysis
├── content.js          — Page overlay, selection tool, result card
├── fracto.css          — All styles for the overlay UI
├── popup.html          — Toolbar popup for API key setup
├── popup.js            — Popup logic
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Requirements

- Google Chrome (or any Chromium browser)
- An Anthropic API key with access to Claude

---

## Privacy

- No data is stored or logged
- Screenshots are sent directly to Anthropic's API for analysis only
- Your API key is stored in Chrome's local sync storage
